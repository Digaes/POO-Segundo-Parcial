
package parcial2poo;

/**
 *
 * @author lymich
 */
public class NotificacionSMS implements Notificacion{

    public NotificacionSMS(){
        
    }
    
    @Override
    public void enviarNotificacion() {
        
    }
    
}
