
package parcial2poo;

/**
 *
 * @author lymich
 */
public interface Notificacion {
    
    public void enviarNotificacion();
        
}
