
package parcial2poo;

/**
 *
 * @author lymich
 */
public class NotificacionEmail implements Notificacion{
    
    public NotificacionEmail(){
        
    }

    @Override
    public void enviarNotificacion() {
        
    }
    
}
